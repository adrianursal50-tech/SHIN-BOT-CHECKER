#!/usr/bin/env python3
# =============================================================================
#  feedback_enforcer.py  —  Simple Feedback Database + Auto-Revocation
#
#  Logic:
#    • Admin adds users with /feedbacked @user or /feedbacked <id>
#    • Any user with lines/keys NOT in the feedbacked DB → auto-revoked
#    • Enforcement loop runs every 60 s
# =============================================================================

import json
import logging
import os
import time
from datetime import datetime
from threading import Lock, Thread

logger = logging.getLogger("CODM_BOT")

# ---------------------------------------------------------------------------
#  File path — set via init_enforcer()
# ---------------------------------------------------------------------------
_SCRIPT_DIR:    str = os.path.dirname(os.path.abspath(__file__))
FEEDBACKED_FILE: str = ""

CHECK_INTERVAL_SECS = 60   # enforcement loop cadence

# ---------------------------------------------------------------------------
#  In-memory DB:  set of int user_ids who gave feedback
# ---------------------------------------------------------------------------
_db:      set = set()
_db_lock: Lock = Lock()


# ===========================================================================
#  Startup
# ===========================================================================

def init_enforcer(script_dir: str):
    """Call once from main.py at startup."""
    global _SCRIPT_DIR, FEEDBACKED_FILE, _db
    _SCRIPT_DIR      = script_dir
    FEEDBACKED_FILE  = os.path.join(script_dir, "feedbacked_db.json")
    _db = _load_db()
    logger.info(f"[FEEDBACK] Initialized — {len(_db)} users in feedbacked DB")


def _load_db() -> set:
    if FEEDBACKED_FILE and os.path.exists(FEEDBACKED_FILE):
        try:
            with open(FEEDBACKED_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            return set(int(x) for x in data)
        except Exception:
            pass
    return set()


def _save_db():
    if not FEEDBACKED_FILE:
        return
    try:
        with open(FEEDBACKED_FILE, "w", encoding="utf-8") as f:
            json.dump(sorted(_db), f, indent=2)
    except Exception as e:
        logger.error(f"[FEEDBACK] DB save error: {e}")


# ===========================================================================
#  Public API
# ===========================================================================

def add_feedbacked(user_id: int) -> bool:
    """Mark user as feedbacked. Returns True if newly added."""
    with _db_lock:
        if user_id in _db:
            return False
        _db.add(user_id)
        _save_db()
    logger.info(f"[FEEDBACK] ✅ {user_id} added to feedbacked DB")
    return True


def remove_feedbacked(user_id: int) -> bool:
    """Remove user from feedbacked DB. Returns True if they were present."""
    with _db_lock:
        if user_id not in _db:
            return False
        _db.discard(user_id)
        _save_db()
    logger.info(f"[FEEDBACK] ❌ {user_id} removed from feedbacked DB")
    return True


def is_feedbacked(user_id: int) -> bool:
    """Check if user is in the feedbacked DB."""
    with _db_lock:
        return user_id in _db


def get_all_feedbacked() -> list[int]:
    """Return sorted list of all feedbacked user IDs."""
    with _db_lock:
        return sorted(_db)


def get_db_count() -> int:
    with _db_lock:
        return len(_db)


# ===========================================================================
#  Resource check helper
# ===========================================================================

def _user_has_lines(u: dict) -> bool:
    """True when user has anything to lose (budget lines, bonus, or active key)."""
    if int(u.get("lines_budget", 0) or 0) > 0:
        return True
    if int((u.get("quota") or {}).get("bonus", 0) or 0) > 0:
        return True
    kexp = u.get("key_expires", "")
    if kexp:
        try:
            return datetime.fromisoformat(kexp) >= datetime.now()
        except Exception:
            pass
    return False


# ===========================================================================
#  Revocation
# ===========================================================================

def revoke_user_key(
    user_id: int,
    load_users, save_users,
    load_keys,  save_keys,
    users_lock: Lock, keys_lock: Lock,
    reason: str = "auto-revoke: not in feedbacked database",
) -> tuple[bool, str]:
    """
    Zero lines_budget, quota.bonus, key, and key_expires for a user.
    Also marks the key as revoked in keys.json.
    """
    uid = str(user_id)
    try:
        with users_lock:
            users = load_users()
            u     = users.get(uid, {})
            if not u:
                return False, "user not found"

            old_budget = int(u.get("lines_budget", 0) or 0)
            old_key    = u.get("key", "")
            old_bonus  = int((u.get("quota") or {}).get("bonus", 0) or 0)

            u["lines_budget"]   = 0
            u["key_expires"]    = None
            u["key"]            = ""
            u["revoked_at"]     = datetime.now().isoformat()
            u["revoked_reason"] = reason
            if u.get("quota"):
                u["quota"]["bonus"] = 0
            users[uid] = u
            save_users(users)

        if old_key:
            with keys_lock:
                keys = load_keys()
                k    = keys.get(old_key)
                if k:
                    k["revoked"]        = True
                    k["revoked_at"]     = datetime.now().isoformat()
                    k["revoked_reason"] = reason
                    save_keys(keys)

        parts = []
        if old_budget: parts.append(f"{old_budget:,} budget lines")
        if old_bonus:  parts.append(f"{old_bonus:,} bonus lines")
        if old_key:    parts.append(f"key '{old_key}'")
        summary = ", ".join(parts) if parts else "nothing (already empty)"
        logger.info(f"[FEEDBACK] 🔴 Revoked {user_id}: {summary}")
        return True, summary

    except Exception as e:
        logger.error(f"[FEEDBACK] Error revoking {user_id}: {e}")
        return False, str(e)


def _notify_revoked(bot, user_id: int):
    try:
        bot.send_message(
            user_id,
            "🔴 <b>Lines & Key Removed — No Feedback</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "Your key and all line balances have been <b>automatically removed</b> "
            "because you are not in the feedback database.\n\n"
            "<b>To get your access back:</b>\n"
            "1️⃣ Post feedback in the group\n"
            "2️⃣ Contact an admin to add you to the database\n\n"
            "<i>Thank you for understanding.</i>",
            parse_mode="HTML",
        )
    except Exception:
        pass


# ===========================================================================
#  Core enforcement pass
# ===========================================================================

def check_and_revoke_all(
    bot,
    admin_ids: set,
    load_users,
    save_users,
    load_keys,
    save_keys,
    users_lock: Lock,
    keys_lock:  Lock,
    notify_chat_id: int | None = None,
) -> dict:
    """
    Single enforcement pass:
      • Skip admins
      • Skip users already in feedbacked DB
      • Skip users with no lines
      • Revoke everyone else (has lines but NOT feedbacked)
    """
    users = load_users()

    revoked_list:  list = []
    skipped_count: int  = 0

    for uid_str, u in users.items():
        try:
            user_id = int(uid_str)
        except ValueError:
            continue

        # Always skip admins
        if user_id in admin_ids:
            skipped_count += 1
            continue

        # In feedbacked DB → safe
        if is_feedbacked(user_id):
            skipped_count += 1
            continue

        # No lines/key → nothing to revoke
        if not _user_has_lines(u):
            skipped_count += 1
            continue

        # Has lines but NOT feedbacked → revoke
        name = u.get("username") or u.get("first_name") or uid_str
        ok, summary = revoke_user_key(
            user_id, load_users, save_users, load_keys, save_keys,
            users_lock, keys_lock,
        )
        if ok:
            revoked_list.append((user_id, name, summary))
            _notify_revoked(bot, user_id)

    result = {
        "revoked": revoked_list,
        "skipped": skipped_count,
        "total":   len(users),
        "ran_at":  datetime.now().isoformat(),
    }
    logger.info(
        f"[FEEDBACK] Pass — revoked: {len(revoked_list)}, "
        f"skipped: {skipped_count}, total: {len(users)}"
    )
    if notify_chat_id:
        _send_report(bot, notify_chat_id, result)
    return result


def _send_report(bot, chat_id: int, result: dict):
    revoked = result["revoked"]
    lines   = [
        "<b>🔍 Feedback Enforcement Report</b>",
        "━━━━━━━━━━━━━━━━━━━━━━━━━━",
        f"<b>Total users:</b>  {result['total']}",
        f"<b>🔴 Revoked:</b>   {len(revoked)}",
        f"<b>✅ Skipped:</b>   {result['skipped']}  (feedbacked / no lines / admin)",
    ]
    if revoked:
        lines.append("\n<b>🔴 Revoked users:</b>")
        for uid, name, summary in revoked[:15]:
            lines.append(f"  • <code>{uid}</code>  @{name}")
        if len(revoked) > 15:
            lines.append(f"  … +{len(revoked) - 15} more")
    try:
        bot.send_message(chat_id, "\n".join(lines), parse_mode="HTML")
    except Exception as e:
        logger.error(f"[FEEDBACK] Report send error: {e}")


# ===========================================================================
#  Background loop
# ===========================================================================

def start_enforcement_loop(
    bot,
    admin_ids: set,
    load_users,
    save_users,
    load_keys,
    save_keys,
    users_lock: Lock,
    keys_lock:  Lock,
    report_chat_id: int | None = None,
):
    """Start background daemon thread — runs enforcement every 60 s."""
    def _loop():
        logger.info(
            f"[FEEDBACK] Loop started — checking every {CHECK_INTERVAL_SECS}s"
        )
        time.sleep(15)   # short startup delay
        while True:
            try:
                check_and_revoke_all(
                    bot, admin_ids,
                    load_users, save_users,
                    load_keys,  save_keys,
                    users_lock, keys_lock,
                    notify_chat_id=report_chat_id,
                )
            except Exception as e:
                logger.error(f"[FEEDBACK] Loop error: {e}", exc_info=True)
            time.sleep(CHECK_INTERVAL_SECS)

    t = Thread(target=_loop, daemon=True, name="FeedbackEnforcer")
    t.start()
    return t
